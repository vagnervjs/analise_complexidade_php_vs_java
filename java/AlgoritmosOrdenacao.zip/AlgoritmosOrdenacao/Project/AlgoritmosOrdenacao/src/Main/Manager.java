/*
 *
 */
package Main;

import display.ConfigPanel;
import display.ResultPanel;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import javax.imageio.ImageIO;
import sort.*;

/**
 *  Manager of sort execution
 */
public class Manager {

    private static int VECTOR_SIZE = 0;             // Vector size
    private static int NUM_ELEM = 0;                // Number of elements stored in vector
    private static final int NUM_VAL_MAX = 1000000; // Value max of element
    private static final int NUM_EXEC = 10;         // Number of execute sort to result

    private ArrayList<double[]> storedGraphResult;  // Data to file results

    private String[][] tableResult;                 // Data to table results

    private double[] graphResult;                   // Data to graph results

    private int[] vectorBackup,                     // Original vector
                  vector;                           // Vector to sort

    // Sort objects
    private BubbleSort1 bubbleSort1;
    private BubbleSort2 bubbleSort2;
    private DirectSelection directSelection;
    private HeapSort heapSort;
    private InsertionSort insertionSort;
    private MergeSort mergeSort;
    private QuickSort quickSort;
    private ShellSort shellSort;

    private ResultPanel resultPanel;
    private ConfigPanel configPanel;

    private boolean finishedRun,
                    flagBubbleSort1,
                    flagBubbleSort2,
                    flagDirectSelection,
                    flagHeapSort,
                    flagInsertionSort,
                    flagMergeSort,
                    flagQuickSort,
                    flagShellSort,
                    flagRandom,
                    flagAsc,
                    flagDesc;

    private boolean runExecuted;

    SortThread sortThread;                          // Thread to run sort

    public Manager() {

        finishedRun = true;
        runExecuted = false;

        storedGraphResult = new ArrayList<double[]>();

        bubbleSort1 = new BubbleSort1();
        bubbleSort2 = new BubbleSort2();
        directSelection = new DirectSelection();
        heapSort = new HeapSort();
        insertionSort = new InsertionSort();
        mergeSort = new MergeSort();
        quickSort = new QuickSort();
        shellSort = new ShellSort();
    }

    /*
     * Set the panel result
     * 
     * @param   resultPanel     Panel result
     */
    public void setResultPanel(ResultPanel resultPanel) {

        this.resultPanel = resultPanel;
    }

    /*
     * Set the config result
     * 
     * @param   configPanel     Panel config
     */
    public void setConfigPanel(ConfigPanel configPanel) {

        this.configPanel = configPanel;
    }

    /*
     * Get number of elements in vector
     * 
     * @return   Number of elements
     */
    public int getVectorSize() {

        return NUM_ELEM;
    }
    
    /*
     * Get number of executions
     * 
     * @return   Number of executions
     */
    public int getNumExec() {

        return NUM_EXEC;
    }

    /*
     * Launch thread to execute sort
     * 
     * @param   sizeVetor               Number of elements in vector
     * @param   flagBubbleSort1         Set if BubbleSort1 runs
     * @param   flagBubbleSort2         Set if BubbleSort2 runs
     * @param   flagDirectSelection     Set if DirectSelection runs
     * @param   flagHeapSort            Set if HeapSort runs
     * @param   flagInsertionSort       Set if InsertionSort runs
     * @param   flagMergeSort           Set if MergeSort runs
     * @param   flagQuickSort           Set if QuickSort runs
     * @param   flagShellSort           Set if ShellSort runs
     * @param   flagRandom              Set Random vector
     * @param   flagAsc                 Set Asc vector
     * @param   flagDesc                Set Desc vector
     */
    public void run(int sizeVector, boolean flagBubbleSort1, boolean flagBubbleSort2,
                    boolean flagDirectSelection, boolean flagHeapSort, boolean flagInsertionSort,
                    boolean flagMergeSort, boolean flagQuickSort, boolean flagShellSort,
                    boolean flagRandom, boolean flagAsc, boolean flagDesc) {

        finishedRun = false;

        if (sizeVector < 0) {
            return;
        }

        VECTOR_SIZE = sizeVector + 1;
        NUM_ELEM = sizeVector;

        System.out.println("Vector_Size: " + VECTOR_SIZE + " Num_Elem: " + NUM_ELEM);
        
        this.flagBubbleSort1 = flagBubbleSort1;
        this.flagBubbleSort2 = flagBubbleSort2;
        this.flagDirectSelection = flagDirectSelection;
        this.flagHeapSort = flagHeapSort;
        this.flagInsertionSort = flagInsertionSort;
        this.flagMergeSort = flagMergeSort;
        this.flagQuickSort = flagQuickSort;
        this.flagShellSort = flagShellSort;

        this.flagRandom = flagRandom;
        this.flagAsc = flagAsc;
        this.flagDesc = flagDesc;

        if (!flagBubbleSort1 && !flagBubbleSort2 && !flagDirectSelection && !flagHeapSort
            && !flagInsertionSort && !flagMergeSort && !flagQuickSort && !flagShellSort) {
            return;
        }

        vector = new int[VECTOR_SIZE];
        vectorBackup = new int[VECTOR_SIZE];

        sortThread = new SortThread();
        sortThread.start();
    }

    /*
     * Indicate if run is finished
     * 
     * @return  true if finished or false, if not
     */
    public boolean isFinishedRun() {

        return finishedRun;
    }

    /*
     * Indicate if vector is random
     * 
     * @return  true or false
     */
    public boolean isRandomVector() {

        return flagRandom;
    }

    /*
     * Indicate if vector is asc
     * 
     * @return  true or false
     */
    public boolean isAscVector() {

        return flagAsc;
    }

    /*
     * Indicate if vector is desc
     * 
     * @return  true or false
     */
    public boolean isDescVector() {

        return flagDesc;
    }

    /*
     * Indicate if already run
     * 
     * @return  true or false
     */
    public boolean runExecuted() {

        return runExecuted;
    }

    /*
     * Get vector result to table
     * 
     * @return  Vector result
     */
    public String[][] getTableResult() {

        return tableResult;
    }

    /*
     * Get vector result to graph
     * 
     * @return  Graph result
     */
     public double[] getGraphResult() {

        return graphResult;
    }

    /*
     * Clear results of run
     */
    public void clearRun() {

        finishedRun = true;
        runExecuted = false;

        clearTableResult();
        clearGraphResult();

        storedGraphResult.clear();

        resultPanel.clear();
    }

    /*
     * Clear table results
     */
    private void clearTableResult() {

        int a = 0;

        tableResult = new String[9][2];

        for (a = 0; a < tableResult.length; a++) {
            //tableResult[a][0] = "";
            tableResult[a][1] = "";
        }

        tableResult[0][0] = "BubbleSort1";
        tableResult[1][0] = "BubbleSort2";
        tableResult[2][0] = "DirectSelection";
        tableResult[3][0] = "HeapSort";
        tableResult[4][0] = "InsertionSort";
        tableResult[5][0] = "MergeSort";
        tableResult[6][0] = "QuickSort";
        tableResult[7][0] = "ShellSort";
    }

    /*
     * Clear graph results
     */
    private void clearGraphResult() {

        int a = 0;

        graphResult = new double[9];

        for (a = 0; a < graphResult.length; a++) {
            graphResult[a] = 0;
        }
    }

    /*
     * Class of Thread for run sort
     */
    class SortThread extends Thread {

         SortThread() {
         }

        /*
         * Run sort
         */
         public void run() {

            int runExec = 0;
            double average = 0;
             
            String ret;

            configPanel.lockConfig();

            clearTableResult();
            clearGraphResult();

            if (flagAsc) {
                data.DataSort.createAscVector(vectorBackup, NUM_ELEM, NUM_VAL_MAX);
            } else if (flagDesc) {
                data.DataSort.createDescVector(vectorBackup, NUM_ELEM, NUM_VAL_MAX);
            } else {
                data.DataSort.createRandomVector(vectorBackup, NUM_ELEM, NUM_VAL_MAX);
            }

            if (flagBubbleSort1) {
                for (runExec = 0, average = 0; runExec < NUM_EXEC; runExec++) {
                    System.arraycopy(vectorBackup, 0, vector, 0, NUM_ELEM);
                    //verifySort(vector, NUM_ELEM);
                    bubbleSort1.sort(vector, NUM_ELEM);
                    //verifySort(vector, NUM_ELEM);
                    average += bubbleSort1.getExecutionTime();
                }
                average = average / NUM_EXEC;
                ret = bubbleSort1.getStrSecExecutionTime(average) + " - " + average + " ms";
                System.out.println("BubbleSort1:\t\t" + ret);
                tableResult[0][1] = ret;
                graphResult[0] = average;
                //data.DataSort.printVector("-", vector, NUM_ELEM);
            } else {
                tableResult[0][1] = "-";
            }

            if (flagBubbleSort2) {
                for (runExec = 0, average = 0; runExec < NUM_EXEC; runExec++) {
                    System.arraycopy(vectorBackup, 0, vector, 0, NUM_ELEM);
                    //verifySort(vector, NUM_ELEM);
                    bubbleSort2.sort(vector, NUM_ELEM);
                    //verifySort(vector, NUM_ELEM);
                    average += bubbleSort2.getExecutionTime();
                }
                average = average / NUM_EXEC;
                ret = bubbleSort2.getStrSecExecutionTime(average) + " - " + average + " ms";
                System.out.println("BubbleSort2:\t\t" + ret);
                tableResult[1][1] = ret;
                graphResult[1] = average;
                //data.DataSort.printVector("-", vector, NUM_ELEM);
            } else {
                tableResult[1][1] = "-";
            }

            if (flagDirectSelection) {
                for (runExec = 0, average = 0; runExec < NUM_EXEC; runExec++) {
                    System.arraycopy(vectorBackup, 0, vector, 0, NUM_ELEM);
                    //verifySort(vector, NUM_ELEM);
                    directSelection.sort(vector, NUM_ELEM);
                    //verifySort(vector, NUM_ELEM);
                    average += directSelection.getExecutionTime();
                }
                average = average / NUM_EXEC;
                ret = directSelection.getStrSecExecutionTime(average) + " - " + average + " ms";
                System.out.println("DirectSelection:\t\t" + ret);
                tableResult[2][1] = ret;
                graphResult[2] = average;
                //data.DataSort.printVector("-", vector, NUM_ELEM);
            } else {
                tableResult[2][1] = "-";
            }

            if (flagHeapSort) {
                for (runExec = 0, average = 0; runExec < NUM_EXEC; runExec++) {
                    System.arraycopy(vectorBackup, 0, vector, 0, NUM_ELEM);
                    //verifySort(vector, NUM_ELEM);
                    heapSort.sort(vector, NUM_ELEM);
                    //verifySort(vector, NUM_ELEM);
                    average += heapSort.getExecutionTime();
                }
                average = average / NUM_EXEC;
                ret = heapSort.getStrSecExecutionTime(average) + " - " + average + " ms";
                System.out.println("HeapSort:\t\t" + ret);
                tableResult[3][1] = ret;
                graphResult[3] = average;
                //data.DataSort.printVector("-", vector, NUM_ELEM);
            } else {
                tableResult[3][1] = "-";
            }

            if (flagInsertionSort) {
                for (runExec = 0, average = 0; runExec < NUM_EXEC; runExec++) {
                    System.arraycopy(vectorBackup, 0, vector, 0, NUM_ELEM);
                    //verifySort(vector, NUM_ELEM);
                    insertionSort.sort(vector, NUM_ELEM);
                    //verifySort(vector, NUM_ELEM);
                    average += insertionSort.getExecutionTime();
                }
                average = average / NUM_EXEC;
                ret = insertionSort.getStrSecExecutionTime(average) + " - " + average + " ms";
                System.out.println("InsertionSort:\t\t" + ret);
                tableResult[4][1] = ret;
                graphResult[4] = average;
                //data.DataSort.printVector("-", vector, NUM_ELEM);
            } else {
                tableResult[4][1] = "-";
            }

            if (flagMergeSort) {
                for (runExec = 0, average = 0; runExec < NUM_EXEC; runExec++) {
                    System.arraycopy(vectorBackup, 0, vector, 0, NUM_ELEM);
                    //verifySort(vector, NUM_ELEM);
                    mergeSort.sort(vector, NUM_ELEM);
                    //verifySort(vector, NUM_ELEM);
                    average += mergeSort.getExecutionTime();
                }
                average = average / NUM_EXEC;
                ret = mergeSort.getStrSecExecutionTime(average) + " - " + average + " ms";
                System.out.println("MergeSort:\t\t" + ret);
                tableResult[5][1] = ret;
                graphResult[5] = average;
                //data.DataSort.printVector("-", vector, NUM_ELEM);
            } else {
                tableResult[5][1] = "-";
            }

            if (flagQuickSort) {
                for (runExec = 0, average = 0; runExec < NUM_EXEC; runExec++) {
                    System.arraycopy(vectorBackup, 0, vector, 0, NUM_ELEM);
                    //verifySort(vector, NUM_ELEM);
                    quickSort.sort(vector, NUM_ELEM);
                    //verifySort(vector, NUM_ELEM);
                    average += quickSort.getExecutionTime();
                }
                average = average / NUM_EXEC;
                ret = quickSort.getStrSecExecutionTime(average) + " - " + average + " ms";
                System.out.println("QuickSort:\t\t" + ret);
                tableResult[6][1] = ret;
                graphResult[6] = average;
                //data.DataSort.printVector("-", vector, NUM_ELEM);
            } else {
                tableResult[6][1] = "-";
            }

            if (flagShellSort) {
                for (runExec = 0, average = 0; runExec < NUM_EXEC; runExec++) {
                    System.arraycopy(vectorBackup, 0, vector, 0, NUM_ELEM);
                    //verifySort(vector, NUM_ELEM);
                    shellSort.sort(vector, NUM_ELEM);
                    //verifySort(vector, NUM_ELEM);
                    average += shellSort.getExecutionTime();
                }
                average = average / NUM_EXEC;
                ret = shellSort.getStrSecExecutionTime(average) + " - " + average + " ms";
                System.out.println("ShellSort:\t\t" + ret);
                tableResult[7][1] = ret;
                graphResult[7] = average;
                //data.DataSort.printVector("-", vector, NUM_ELEM);
            } else {
                tableResult[7][1] = "-";
            }

            graphResult[8] = NUM_ELEM;

            if (isAscVector()) {
                tableResult[8][0] = "Entradas Ascendentes";
            } else if (isDescVector()) {
                tableResult[8][0] = "Entradas Descendentes";
            } else {
                tableResult[8][0] = "Entradas Aleatórias";
            }

            storedGraphResult.add(getGraphResult());

            configPanel.unlockConfig();

            resultPanel.setTableData(getTableResult());
            resultPanel.setGraphData(getGraphResult(), NUM_ELEM);

            finishedRun = true;
            runExecuted = true;
        }
    }

    /*
     * Save results in file text
     * 
     * @param   filePath    Path to file
     */
    public void saveResultText(String filePath) throws IOException {

        filePath += ".txt";

        Iterator<double[]> i = storedGraphResult.iterator();
        double temp[];
        int a = 0;

        FileWriter fstream = new FileWriter(filePath);
        BufferedWriter out = new BufferedWriter(fstream);

        for (; i.hasNext();) {
            temp = (double[])i.next();
            out.write(temp[8] + ";" + tableResult[8][0] + ";\n");
            for (a = 0; a < tableResult.length - 1; a++) {
                out.write(tableResult[a][0] + ";" + temp[a] + ";\n");
            }
            out.write("---\n");
        }

        out.close();
    }

    /*
     * Save graph result in image
     * 
     * @param   filePath    Path to file
     */
    public void saveResultImage(String filePath) throws IOException {

        filePath += ".png";

        BufferedImage bi = resultPanel.createGraphImage();
        File outputfile = new File(filePath);

        ImageIO.write(bi, "png", outputfile);
    }
    
    /*
     * Verify if vector is orderly
     * 
     * @param   vector      Vector
     * @param   size        Number of elements
     */
    public static void verifySort(int[] vector, int size) {
        
        int a = 0;
        
        for (a = 0; a < (size - 1); a++) {
            if (vector[a] > vector[a+1]) {
                System.out.println(" - Não ordenado");
                return;
            }
        }
        
        System.out.println(" - Ordenado");
    }
}
