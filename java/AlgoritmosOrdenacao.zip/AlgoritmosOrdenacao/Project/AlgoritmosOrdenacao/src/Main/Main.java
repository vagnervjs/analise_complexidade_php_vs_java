/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import display.MainWindow;



/**
 *
 * @author server_x1
 */
public class Main {

    public static void main(String[] args) {

        Manager manager = new Manager();

        MainWindow mainWindow = new MainWindow("Algoritmos de Ordenação", manager);

        mainWindow.setVisible(true);
    }
}
