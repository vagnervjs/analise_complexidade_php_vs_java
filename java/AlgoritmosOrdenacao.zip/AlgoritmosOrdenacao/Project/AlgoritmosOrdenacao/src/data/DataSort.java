/*
 *
 */
package data;

import java.util.Random;

/**
 *
 */
public class DataSort {

    public DataSort() {

    }

    public static boolean createRandomVector(int vector[], int size, int max) {

        int a = 0;

        Random r = new Random();

        if (vector.length < size) {
            return false;
        }

        for (a = 0; a < size; a++) {
            vector[a] = r.nextInt(max);
        }

        //printVector("Random", vector, size);

        return true;
    }

    public static boolean createAscVector(int vector[], int size, int start) {

        int a = 0,
            num = start;

        if (vector.length < size) {
            return false;
        }

        for (a = 0; a < size; a++) {
            vector[a] = num;
            num++;
        }

        //printVector("Asc", vector, size);

        return true;
    }

    public static boolean createDescVector(int vector[], int size, int start) {

        int a = 0,
            num = start;

        if (vector.length < size) {
            return false;
        }

        for (a = 0; a < size; a++) {
            vector[a] = num;
            num--;
        }

        //printVector("Desc", vector, size);

        return true;
    }

    public static void printVector(String tag, int vector[], int size) {

        int a = 0;

        if (vector.length < size) {
            return;
        }

        System.out.println("[" + tag + "]");
        for (a = 0; a < size; a++) {
            System.out.println(vector[a] + " | ");
        }
    }
}
