/* ===========================================================
 * JFreeChart : a free chart library for the Java(tm) platform
 * ===========================================================
 *
 * (C) Copyright 2000-2004, by Object Refinery Limited and Contributors.
 *
 * Project Info:  http://www.jfree.org/jfreechart/index.html
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation;
 * either version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * library; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * [Java is a trademark or registered trademark of Sun Microsystems, Inc.
 * in the United States and other countries.]
 *
 * -------------------
 * LineChartDemo6.java
 * -------------------
 * (C) Copyright 2004, by Object Refinery Limited and Contributors.
 *
 * Original Author:  David Gilbert (for Object Refinery Limited);
 * Contributor(s):   -;
 *
 * $Id: LineChartDemo6.java,v 1.5 2004/04/26 19:11:55 taqua Exp $
 *
 * Changes
 * -------
 * 27-Jan-2004 : Version 1 (DG);
 *
 */
package display;

import Main.Manager;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

/**
 * A simple demonstration application showing how to create a line chart using data from an
 * {@link XYDataset}.
 *
 */
public class GraphPanel extends JPanel {

    public static final int PANEL_WIDTH = 500;
    public static final int PANEL_HEIGHT = 350;

    Manager manager;

    private XYSeries seriesBubbleSort1,
                        seriesBubbleSort2,
                        seriesDirectSelection,
                        seriesHeapSort,
                        seriesInsertionSort,
                        seriesMergeSort,
                        seriesQuickSort,
                        seriesShellSort;

    private XYSeriesCollection dataset;
    private JFreeChart chart;
    private ChartPanel chartPanel;

    /**
     * Creates a GraphPanel
     *
     * @param manager  Manager of execution
     */
    public GraphPanel(Manager manager) {

        super(new BorderLayout());

        this.manager = manager;

        init();
    }

    private void init() {

        dataset = new XYSeriesCollection();

        seriesBubbleSort1 = new XYSeries("BubbleSort1");
        seriesBubbleSort2 = new XYSeries("BubbleSort2");
        seriesDirectSelection = new XYSeries("DirectSelection");
        seriesHeapSort = new XYSeries("HeapSort");
        seriesInsertionSort = new XYSeries("InsertionSort");
        seriesMergeSort = new XYSeries("MergeSort");
        seriesQuickSort = new XYSeries("QuickSort");
        seriesShellSort = new XYSeries("ShellSort");

        dataset.addSeries(seriesBubbleSort1);
        dataset.addSeries(seriesBubbleSort2);
        dataset.addSeries(seriesDirectSelection);
        dataset.addSeries(seriesHeapSort);
        dataset.addSeries(seriesInsertionSort);
        dataset.addSeries(seriesMergeSort);
        dataset.addSeries(seriesQuickSort);
        dataset.addSeries(seriesShellSort);

        chart = createChart(dataset);

        chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new java.awt.Dimension(PANEL_WIDTH, PANEL_HEIGHT));

        add(chartPanel, BorderLayout.CENTER);
    }

    public void clear() {

        seriesBubbleSort1.clear();
        seriesBubbleSort2.clear();
        seriesDirectSelection.clear();
        seriesHeapSort.clear();
        seriesInsertionSort.clear();
        seriesMergeSort.clear();
        seriesQuickSort.clear();
        seriesShellSort.clear();
    }

    public void addDataset(double XseriesBubbleSort1, double YseriesBubbleSort1,
            double XseriesBubbleSort2, double YseriesBubbleSort2,
            double XseriesDirectSelection, double YseriesDirectSelection,
            double XseriesHeapSort, double YseriesHeapSort,
            double XseriesInsertionSort, double YseriesInsertionSort,
            double XseriesMergeSort, double YseriesMergeSort,
            double XseriesQuickSort, double YseriesQuickSort,
            double XseriesShellSort, double YseriesShellSort) {

        seriesBubbleSort1.add(XseriesBubbleSort1, YseriesBubbleSort1);
        seriesBubbleSort2.add(XseriesBubbleSort2, YseriesBubbleSort2);
        seriesDirectSelection.add(XseriesDirectSelection, YseriesDirectSelection);
        seriesHeapSort.add(XseriesHeapSort, YseriesHeapSort);
        seriesInsertionSort.add(XseriesInsertionSort, YseriesInsertionSort);
        seriesMergeSort.add(XseriesMergeSort, YseriesMergeSort);
        seriesQuickSort.add(XseriesQuickSort, YseriesQuickSort);
        seriesShellSort.add(XseriesShellSort, YseriesShellSort);
    }

    private JFreeChart createChart(final XYDataset dataset) {

        final JFreeChart chart = ChartFactory.createXYLineChart(
                "Análise de Algoritmos de Ordenação",
                "Tamanho do Vetor (x" + ResultPanel.DIV + ")",
                "Tempo de execução (ms)",
                dataset,
                PlotOrientation.VERTICAL,
                true,
                true,
                false);

        chart.setBackgroundPaint(Color.white);

        final XYPlot plot = chart.getXYPlot();
        plot.setBackgroundPaint(Color.WHITE);
        plot.setDomainGridlinePaint(Color.GRAY);
        plot.setRangeGridlinePaint(Color.GRAY);

        final XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
        renderer.setSeriesLinesVisible(0, true);
        renderer.setSeriesShapesVisible(1, true);
        plot.setRenderer(renderer);

        final NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
        rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());

        return chart;
    }
}