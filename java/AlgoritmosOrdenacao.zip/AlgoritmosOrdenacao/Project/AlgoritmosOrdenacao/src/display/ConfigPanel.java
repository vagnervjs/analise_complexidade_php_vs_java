/*
 *
 */
package display;

import Main.Manager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 *
 * @author Luiz
 */
public class ConfigPanel extends JPanel implements ActionListener {

    Manager manager;

    private JTextField fieldSizeVector;

    JPanel configVector,
           configSort;

    private JRadioButton radioRandom,
                         radioAsc,
                         radioDesc;
    private JCheckBox checkBubbleSort1,
                      checkBubbleSort2,
                      checkDirectSelection,
                      checkHeapSort,
                      checkInsertionSort,
                      checkMergeSort,
                      checkQuickSort,
                      checkShellSort,
                      checkAll;

    private JButton execute,
                    clear,
                    save,
                    saveImage;

    private JFileChooser fileChooser,
                         imageChooser;
    private FileNameExtensionFilter filterTxt,
                                    filterPng;

    private JRadioButton currentRadio;

    public ConfigPanel(Manager manager) {

        super(new VerticalFlowLayout(VerticalFlowLayout.TOP));

        filterTxt = new FileNameExtensionFilter(".txt", "txt");
        filterPng = new FileNameExtensionFilter(".png", "png");
        fileChooser = new JFileChooser();
        imageChooser = new JFileChooser();
        fileChooser.setFileFilter(filterTxt);
        imageChooser.setFileFilter(filterPng);

        this.manager = manager;

        init();
    }
    private void init() {

        ButtonGroup btnGroup1 = new ButtonGroup();

        execute = new JButton("Executar");
        clear = new JButton("Limpar");
        save = new JButton("Salvar Resultado");
        saveImage = new JButton("Salvar Imagem");

        execute.addActionListener(this);
        clear.addActionListener(this);
        save.addActionListener(this);
        saveImage.addActionListener(this);

        JLabel tittle;

        fieldSizeVector = new JTextField(9);

        configVector = new JPanel(new VerticalFlowLayout(VerticalFlowLayout.LEFT));
        configSort = new JPanel(new VerticalFlowLayout(VerticalFlowLayout.LEFT));

        radioRandom = new JRadioButton("Entrada Aleatória");
        radioAsc = new JRadioButton("Entrada Ascendente");
        radioDesc = new JRadioButton("Entrada Descendente");

        radioRandom.addActionListener(this);
        radioAsc.addActionListener(this);
        radioDesc.addActionListener(this);

        checkBubbleSort1 = new JCheckBox("BubbleSort1");
        checkBubbleSort2 = new JCheckBox("BubbleSort2");
        checkDirectSelection = new JCheckBox("DirectSelection");
        checkHeapSort = new JCheckBox("HeapSort");
        checkInsertionSort = new JCheckBox("InsertionSort");
        checkMergeSort = new JCheckBox("MergeSort");
        checkQuickSort = new JCheckBox("QuickSort");
        checkShellSort = new JCheckBox("ShellSort");

        checkAll = new JCheckBox("Todos");

        configVector.setBorder(new TitledBorder("Vetor"));
        configSort.setBorder(new TitledBorder("Ordenação"));

        btnGroup1.add(radioRandom);
        btnGroup1.add(radioAsc);
        btnGroup1.add(radioDesc);

        radioRandom.setSelected(true);

        configVector.add(radioRandom);
        configVector.add(radioAsc);
        configVector.add(radioDesc);

        checkAll.addActionListener(this);
        checkBubbleSort1.addActionListener(this);
        checkBubbleSort2.addActionListener(this);
        checkDirectSelection.addActionListener(this);
        checkHeapSort.addActionListener(this);
        checkInsertionSort.addActionListener(this);
        checkMergeSort.addActionListener(this);
        checkQuickSort.addActionListener(this);
        checkShellSort.addActionListener(this);

        configSort.add(checkAll);
        configSort.add(checkBubbleSort1);
        configSort.add(checkBubbleSort2);
        configSort.add(checkDirectSelection);
        configSort.add(checkHeapSort);
        configSort.add(checkInsertionSort);
        configSort.add(checkMergeSort);
        configSort.add(checkQuickSort);
        configSort.add(checkShellSort);

        tittle = new JLabel("Tamanho do vetor", JLabel.CENTER);

        add(tittle);
        add(fieldSizeVector);

        add(configVector);
        add(configSort);

        add(execute);
        add(clear);
        add(save);
        add(saveImage);

        setBorder(new TitledBorder("Execução"));
    }

    private void unmakeAll() {

        checkAll.setSelected(false);
        checkBubbleSort1.setSelected(false);
        checkBubbleSort2.setSelected(false);
        checkDirectSelection.setSelected(false);
        checkHeapSort.setSelected(false);
        checkInsertionSort.setSelected(false);
        checkMergeSort.setSelected(false);
        checkQuickSort.setSelected(false);
        checkShellSort.setSelected(false);
    }

    private void makeAll() {

        checkAll.setSelected(true);
        checkBubbleSort1.setSelected(true);
        checkBubbleSort2.setSelected(true);
        checkDirectSelection.setSelected(true);
        checkHeapSort.setSelected(true);
        checkInsertionSort.setSelected(true);
        checkMergeSort.setSelected(true);
        checkQuickSort.setSelected(true);
        checkShellSort.setSelected(true);
    }

    public void lockConfig() {

        execute.setText("Aguarde...");

        execute.setEnabled(false);
        clear.setEnabled(false);
        save.setEnabled(false);
        saveImage.setEnabled(false);
    }

    public void unlockConfig() {

        execute.setText("Executar");

        execute.setEnabled(true);
        clear.setEnabled(true);
        save.setEnabled(true);
        saveImage.setEnabled(true);
    }

    public int getSizeVector() {

        int result = 0;

        try {
            result = Integer.parseInt(fieldSizeVector.getText());
        } catch (NumberFormatException ne) {
            result = -1;
        }

        return result;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource().equals(execute)) {
            manager.run(getSizeVector(),
                        checkBubbleSort1.isSelected(), checkBubbleSort2.isSelected(),
                        checkDirectSelection.isSelected(), checkHeapSort.isSelected(),
                        checkInsertionSort.isSelected(), checkMergeSort.isSelected(),
                        checkQuickSort.isSelected(), checkShellSort.isSelected(),
                        radioRandom.isSelected(), radioAsc.isSelected(), radioDesc.isSelected());

        } else if (e.getSource().equals(clear)) {
            manager.clearRun();

        } else if (e.getSource().equals(checkAll)) {
            if (checkAll.isSelected()) {
                makeAll();
            } else {
                unmakeAll();
            }
        } else if (e.getSource().equals(save)) {
            int returnVal;
            returnVal = fileChooser.showSaveDialog(null);
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                File file = fileChooser.getSelectedFile();
                try {
                    manager.saveResultText(file.getAbsolutePath());
                    JOptionPane.showMessageDialog(null, "Arquivo salvo com sucesso", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(null, "Falha ao salvar arquivo", "Falha", JOptionPane.ERROR_MESSAGE);
                }
            }

        } else if (e.getSource().equals(saveImage)) {
            int returnVal;
            returnVal = imageChooser.showSaveDialog(null);
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                File file = imageChooser.getSelectedFile();
                try {
                    manager.saveResultImage(file.getAbsolutePath());
                    JOptionPane.showMessageDialog(null, "Imagem salva com sucesso", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(null, "Falha ao salvar imagem", "Falha", JOptionPane.ERROR_MESSAGE);
                }
            }

        } else if (e.getSource().equals(radioRandom) || e.getSource().equals(radioAsc) || e.getSource().equals(radioDesc)) {
            int returnVal;
            if (manager.runExecuted()) {
                returnVal =JOptionPane.showConfirmDialog(null, "Alterar o vetor reiniciará a análise. Deseja continuar?");
                if (returnVal == JOptionPane.OK_OPTION) {
                    manager.clearRun();
                } else {
                    if (manager.isAscVector()) {
                        radioAsc.setSelected(true);
                    } else if (manager.isDescVector()) {
                        radioDesc.setSelected(true);
                    } else {
                        radioRandom.setSelected(true);
                    }
                }
            }

        } else {
            checkAll.setSelected(false);
        }
    }
}
