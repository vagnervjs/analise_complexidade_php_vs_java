/*
 *
 */
package display;

import Main.Manager;
import java.awt.BorderLayout;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Luiz
 */
public class ResultPanel extends JPanel {

    public static final int DIV = 1000;

    Manager manager;

    private JTable dataTable;

    private GraphPanel graphPanel;

    private JLabel info;
    private DefaultTableCellRenderer rightRenderer;

    String[] columnName = {"Algoritmo", "Tempo de Execução"};

    public ResultPanel(Manager manager) {

        super(new BorderLayout());

        this.manager = manager;

        init();
    }

    private void init() {

        graphPanel = new GraphPanel(manager);

        dataTable = new JTable(new DefaultTableModel());

        dataTable.setEnabled(false);
        
        rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(JLabel.CENTER);

        graphPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JPanel panelTable = new JPanel(new BorderLayout());
        panelTable.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JScrollPane scrollPanel = new JScrollPane(dataTable);
        JLabel tittleTable = new JLabel("Tabela Comparativa", JLabel.CENTER);
        info = new JLabel("-", JLabel.CENTER);

        tittleTable.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));

        panelTable.add(tittleTable, BorderLayout.NORTH);
        panelTable.add(scrollPanel, BorderLayout.CENTER);
        panelTable.add(info, BorderLayout.SOUTH);

        add(graphPanel, BorderLayout.NORTH);
        add(panelTable, BorderLayout.CENTER);

        clear();
    }

    public void clear() {

        DefaultTableModel model = (DefaultTableModel)dataTable.getModel();

        model.getDataVector().removeAllElements();
        model.setColumnIdentifiers(columnName);
        dataTable.revalidate();

        info.setText("-");

        graphPanel.clear();
    }

    public void setTableData(Object[][] data) {

        int a = 0;
        
        DefaultTableModel model = (DefaultTableModel)dataTable.getModel();

        model.setDataVector(data, columnName);
        dataTable.revalidate();
        
        for (a = 0; a < dataTable.getColumnCount(); a++) {
            dataTable.getColumnModel().getColumn(a).setCellRenderer( rightRenderer );
        }
    }

    public void setGraphData(double[] data, int vectorSize) {

        String type;

        graphPanel.addDataset(vectorSize / DIV, data[0],
                              vectorSize / DIV, data[1],
                              vectorSize / DIV, data[2],
                              vectorSize / DIV, data[3],
                              vectorSize / DIV, data[4],
                              vectorSize / DIV, data[5],
                              vectorSize / DIV, data[6],
                              vectorSize / DIV, data[7]);

        if (manager.isAscVector()) {
            type = " ascendentes";
        } else if (manager.isDescVector()) {
            type = " descendentes";
        } else {
            type = " aleatórias";
        }

        info.setText("Resultado para " + vectorSize + " entradas " + type + " (" + manager.getNumExec() + " execuções por algoritmo)");
    }

    public BufferedImage createGraphImage() {

        int w = graphPanel.getWidth();
        int h = graphPanel.getHeight();

        BufferedImage bi = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = bi.createGraphics();
        graphPanel.paint(g);

        return bi;
    }
}
