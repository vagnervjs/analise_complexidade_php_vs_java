/*
 *
 */
package display;

import Main.Manager;
import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 */
public final class MainWindow extends JFrame {

    public static final int WINDOW_WIDTH = 1024;
    public static final int WINDOW_HEIGHT = 650;

    private Manager manager;

    private JPanel panelMain,
                   panelWest,
                   panelCenter;

    private ConfigPanel configPanel;

    private ResultPanel resultPanel;

    public MainWindow(String tittle, Manager manager) {

        super(tittle);

        this.manager = manager;

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(new Dimension(WINDOW_WIDTH, WINDOW_HEIGHT));

        initComponents();
    }

    public void initComponents() {

        panelMain = new JPanel(new BorderLayout());
        panelWest = new JPanel(new BorderLayout());
        panelCenter = new JPanel(new BorderLayout());

        configPanel = new ConfigPanel(manager);
        resultPanel = new ResultPanel(manager);

        manager.setConfigPanel(configPanel);
        manager.setResultPanel(resultPanel);

        panelWest.add(configPanel, BorderLayout.CENTER);
        panelWest.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
        panelCenter.add(resultPanel, BorderLayout.CENTER);
        panelCenter.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));

        panelMain.add(panelWest, BorderLayout.WEST);
        panelMain.add(panelCenter, BorderLayout.CENTER);

        this.setContentPane(panelMain);
    }
}
