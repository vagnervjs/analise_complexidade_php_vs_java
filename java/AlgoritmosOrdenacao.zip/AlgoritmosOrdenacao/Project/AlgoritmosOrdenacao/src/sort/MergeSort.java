/**
 *
 */
package sort;

/**
 *  BubbleSort1 algorithm to sort a int vector
 */
public class MergeSort extends Sort {

    /*
     * Constructor
     */
    public MergeSort() {

        startTime = endTime = 0;
    }

    /*
     * Execute sort
     *
     * @param   vector  Vector for sort
     * @param   size    Number of elements in vector
     */
    @Override
    public void sort(int vector[], int size) {

        setStartTime(System.currentTimeMillis());

        merge(vector, 0, size);

        setEndTime(System.currentTimeMillis());
    }

    /*
     * Run sort using MergeSort
     *
     * @param   vector  Vector for sort
     * @param   start   Position initial to sort
     * @param   end     Position final to sort
     */
    private void merge(int vector[], int start, int end) {

        if (start < end) {
            int middle = (int)((start + end) / 2);
            merge(vector, start, middle);
            merge(vector, middle + 1, end);
            mix(vector, start, middle, end);
        }

    }

    /*
     * Mix
     *
     * @param   vector  Vector for sort
     * @param   start   Position initial to sort
     * @param   start   Middle to sort
     * @param   end     Position final to sort
     */
    private void mix(int vector[], int start, int middle, int end) {

        int tamanho = end - start + 1;

        int[] temp = new int[tamanho];

        System.arraycopy(vector, start, temp, 0, tamanho);

        int i = 0,
            j = middle - start + 1;

        for (int posicao = 0; posicao < tamanho; posicao++) {
            if (j <= tamanho - 1) {
                if (i <= middle - start) {
                    if (temp[i] < temp[j]) {
                        vector[start + posicao] = temp[i++];
                    } else {
                        vector[start + posicao] = temp[j++];
                    }
                } else {
                    vector[start + posicao] = temp[j++];
                }
            } else {
                vector[start + posicao] = temp[i++];
            }
        }
    }
}
