/**
 *
 */
package sort;

/**
 *  BubbleSort1 algorithm to sort a int vector
 */
public class BubbleSort2 extends Sort {

    /*
     * Constructor
     */
    public BubbleSort2() {

        startTime = endTime = 0;
    }

    /*
     * Execute BubbleSort2 in vector
     *
     * @param   vector  Vector for sort
     * @param   size    Number of elements in vector
     */
    @Override
    public void sort(int vector[], int size) {

        int a = 0,
            b = 0,
            temp = 0;

        boolean swap = true;

        setStartTime(System.currentTimeMillis());

        for (a = 0; a < size - 1 && swap; a++) {
            swap = false;
            for (b = 0; b < size - a - 1; b++) {
                if (vector[b] > vector[b + 1]) {
                    swap = true;
                    temp = vector[b];
                    vector[b] = vector[b + 1];
                    vector[b + 1] = temp;
                }
            }
        }

        setEndTime(System.currentTimeMillis());
    }
}
