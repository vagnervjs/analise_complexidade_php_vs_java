/**
 *
 */
package sort;

/**
 *  BubbleSort1 algorithm to sort a int vector
 */
public class BubbleSort1 extends Sort {

    /*
     * Constructor
     */
    public BubbleSort1() {

        startTime = endTime = 0;
    }

    /*
     * Execute BubbleSort1 in vector
     *
     * @param   vector  Vector for sort
     * @param   size    Number of elements in vector
     */
    @Override
    public void sort(int vector[], int size) {

        int a = 0,
            b = 0,
            temp = 0;

        setStartTime(System.currentTimeMillis());

        for (a = 0; a < size - 1; a++) {
            for (b = 0; b < size - a - 1; b++) {
                if (vector[b] > vector[b + 1]) {
                    temp = vector[b];
                    vector[b] = vector[b + 1];
                    vector[b + 1] = temp;
                }
            }
        }

        setEndTime(System.currentTimeMillis());
    }
}
