/**
 *
 */
package sort;

/**
 *  BubbleSort1 algorithm to sort a int vector
 */
public class HeapSort extends Sort {

    /*
     * Constructor
     */
    public HeapSort() {

        startTime = endTime = 0;
    }

    /*
     * Run sort using HeapSort
     *
     * @param   vector  Vector for sort
     * @param   size    Number of elements in vector
     */
    @Override
    public void sort(int vector[], int size) {

        setStartTime(System.currentTimeMillis());

        buildMaxHeap(vector, size);

        for (int i = size - 1; i > 0; i--) {
            swap(vector, i , 0);
            maxHeapify(vector, 0, --size);
        }


        setEndTime(System.currentTimeMillis());
    }

    private void buildMaxHeap(int[] v, int size) {

          for (int i = v.length/2 - 1; i >= 0; i--)
            maxHeapify(v, i , size);

    }

    private void maxHeapify(int[] v, int pos, int n) {

        int maxi;
        int l = 2 * pos + 1;
        int right = 2 * pos + 2;

        if ( (l < n) && (v[l] > v[pos]) ) {
             maxi = l;
        } else {
             maxi = pos;
        }

        if (right < n && v[right] > v[maxi]) {
             maxi = right;
        }

        if (maxi != pos) {
            swap(v, pos, maxi);
            maxHeapify(v, maxi, n);
        }
    }

    private void swap(int[] v, int j, int aposJ) {

        int aux = v[ j ];
        v[ j ] = v[ aposJ ];
        v[ aposJ ] = aux;
    }
}
