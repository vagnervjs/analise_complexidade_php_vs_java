/**
 *
 */
package sort;

import java.util.Stack;

/**
 *  BubbleSort1 algorithm to sort a int vector
 */
public class QuickSort extends Sort {

    /*
     * Constructor
     */
    public QuickSort() {

        startTime = endTime = 0;
    }

    /*
     * Run sort using QuickSort
     *
     * @param   vector  Vector for sort
     * @param   size    Number of elements in vector
     */
    @Override
    public void sort(int vector[], int size) {

        setStartTime(System.currentTimeMillis());

        quickSort(vector, 0, size);

        setEndTime(System.currentTimeMillis());
    }

    /*
     * Execute QuickSort in vector
     *
     * @param   vector  Vector for sort
     * @param   start   Position initial to sort
     * @param   end     Position final to sort
     */
    private void quickSort(int[] vector, int start, int end) {
        
        Stack S = new Stack();
        
        S.push(start);
        S.push(end);
        
        while (!S.empty()) {
            end = (Integer) S.pop();
            start = (Integer) S.pop();
            if (end <= start) {
                continue;
            }
            int i = createPartition(vector, start, end);
            if (i - start > end - i) {
                S.push(start);
                S.push(i - 1);
            }
            S.push(i + 1);
            S.push(end);
            if (end - i >= i - start) {
                S.push(start);
                S.push(i - 1);
            }
        }
    }
    
    /*
     * Create a partition to QuickSort
     *
     * @param   vector  Vector for sort
     * @param   start   Position initial to sort
     * @param   end     Position final to sort
     * 
     * @return  Index partition
     */
    private int createPartition(int vector[], int start, int end) {
        
        int a, down, temp, up, pj;
        
        a = vector[start];
        up = end;
        down = start;
        
        while (down < up) {
            while (vector[down] <= a && down < up) {
                down = down + 1;
            }
            while (vector[up] > a) {
                up = up - 1;
            }

            if (down < up) {
                temp = vector[down];
                vector[down] = vector[up];
                vector[up] = temp;
            }
        }
        vector[start] = vector[up];
        vector[up] = a;
        pj = up;

        return (pj);
    }
}
