/**
 *
 */
package sort;

/**
 *  BubbleSort1 algorithm to sort a int vector
 */
public class DirectSelection extends Sort {

    /*
     * Constructor
     */
    public DirectSelection() {

        startTime = endTime = 0;
    }

    /*
     * Run sort using DirectSelection
     *
     * @param   vector  Vector for sort
     * @param   size    Number of elements in vector
     */
    @Override
    public void sort(int vector[], int size) {

        int a = 0,
            b = 0,
            less = 0,
            index = 0;

        setStartTime(System.currentTimeMillis());

        for (a = 0; a < size; a++) {
            less = a;
            for (b = a + 1; b < size; b++) {
                if (vector[b] < vector[less]) {
                    less = b;
                }
            }
            if (less != a) {
                index = vector[a];
                vector[a] = vector[less];
                vector[less] = index;
            }
        }

        setEndTime(System.currentTimeMillis());
    }
}
