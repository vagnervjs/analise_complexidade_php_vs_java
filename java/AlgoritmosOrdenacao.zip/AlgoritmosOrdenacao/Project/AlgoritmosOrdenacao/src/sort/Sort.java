/*
 *
 */
package sort;

/**
 *  Class for sort objects
 */
public abstract class Sort {

    // Caclculate time of execution
    protected long startTime,
                   endTime;

    /*
     * Get time of start execution
     *
     * @return  start time in milllis seconds
     */
    public long getStartTime() {

        return startTime;
    }

    /*
     * Get time of end execution
     *
     * @return  end time in milllis seconds
     */
    public long getEndTime() {

        return endTime;
    }

    /*
     * Get time of execution
     *
     * @return  execution time in milllis seconds
     */
    public long getExecutionTime() {

        return (endTime - startTime);
    }

    /*
     * Get time of end execution (seconds)
     *
     * @return  end time in string
     */
    public String getStrSecExecutionTime() {

        long time = endTime - startTime;

        int hours = (int)((time / 3600000) % 60),
            minutes = (int)(((time / 60000)) % 60),
            seconds = (int)((time / 1000) % 60);

        return String.format("%02d h %02d min %02d seg", hours, minutes, seconds);
    }
    
    /*
     * Get time of end execution (seconds)
     *
     * @return  end time in string
     */
    public String getStrSecExecutionTime(double average) {

        int hours = (int)((average / 3600000) % 60),
            minutes = (int)(((average / 60000)) % 60),
            seconds = (int)((average / 1000) % 60);

        return String.format("%02d h %02d min %02d seg", hours, minutes, seconds);
    }
    
    /*
     * Get time of end execution (seconds)
     *
     * @return  end time in string
     */
    public String getStrMilExecutionTime() {

        long time = endTime - startTime;

        return String.format("%02d ms", time);
    }

    /*
     * Set time of start execution
     *
     * @param   startTime   Initial time
     */
    protected void setStartTime(long startTime) {

        this.startTime = startTime;
    }

    /*
     * Set time of end execution
     *
     * @param   startTime   Final time
     */
    protected void setEndTime(long endTime) {

        this.endTime = endTime;
    }

    /*
     * Execute BubbleSort1 in vector
     *
     * @param   vector  Vector for sort
     * @param   size    Number of elements in vector
     */
    abstract public void sort(int vector[], int size);
}
