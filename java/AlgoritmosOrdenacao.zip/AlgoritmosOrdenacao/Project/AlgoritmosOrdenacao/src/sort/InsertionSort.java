/**
 *
 */
package sort;

/**
 *  BubbleSort1 algorithm to sort a int vector
 */
public class InsertionSort extends Sort {

    /*
     * Constructor
     */
    public InsertionSort() {

        startTime = endTime = 0;
    }

    /*
     * Run sort using InsertionSort
     *
     * @param   vector  Vector for sort
     * @param   size    Number of elements in vector
     */
    @Override
    public void sort(int vector[], int size) {

        int a = 0,
            b = 0,
            temp = 0;

        setStartTime(System.currentTimeMillis());

        for (a = 1; a < size; a++) {
            temp = vector[a];
            for (b = a - 1; b >= 0 && vector[b] > temp; b--) {
                vector[b + 1] = vector[b];
            }
            vector[b + 1] = temp;
        }

        setEndTime(System.currentTimeMillis());
    }
}
