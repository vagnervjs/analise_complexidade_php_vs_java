/**
 *
 */
package sort;

/**
 *  BubbleSort1 algorithm to sort a int vector
 */
public class ShellSort extends Sort {

    /*
     * Constructor
     */
    public ShellSort() {

        startTime = endTime = 0;
    }

    /*
     * Run sort using ShellSort
     *
     * @param   vector  Vector for sort
     * @param   size    Number of elements in vector
     */
    @Override
    public void sort(int vector[], int size) {

        int h = (int)(size / 2),
            c = 0,
            j = 0;

        setStartTime(System.currentTimeMillis());

        for (; h > 0;) {
            for (int i = h; i < size; i++) {
                c = vector[i];
                j = i;
                while (j >= h && vector[j - h] > c) {
                    vector[j] = vector[j - h];
                    j = j - h;
                }
                vector[j] = c;
            }
            h = (int)(h / 2);
        }

        setEndTime(System.currentTimeMillis());
    }
}
